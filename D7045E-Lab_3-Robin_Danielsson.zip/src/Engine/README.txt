Most of the stuff (>99%) in this folder is from an old project of mine (still my code, no worries).
I have disabled or removed a lot of rendering functionalities in order to decrease the project size, but I don't want to
delete everything yet since it might be useful in the next labs.

Here's a link to the full project: https://github.com/robdan7/Cecilion