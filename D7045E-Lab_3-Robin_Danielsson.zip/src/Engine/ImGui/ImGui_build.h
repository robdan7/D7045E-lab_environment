#pragma once
#define IMGUI_IMPL_OPENGL_LOADER_GLEW

#include <imgui.h>
#include <examples/imgui_impl_glfw.h>
#include <examples/imgui_impl_opengl3.h>
